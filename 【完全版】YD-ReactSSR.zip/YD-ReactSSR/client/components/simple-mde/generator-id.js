let id = 0

export default () => {
  id += 1
  return `simplepostmd-editor-${id}`
}

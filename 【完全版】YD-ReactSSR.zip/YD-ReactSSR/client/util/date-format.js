import dateFormat from 'dateformat'

export default (date, format) => {
  return dateFormat(date, format)
}

module.exports = {
  cdn: {
    ak: 'XRG7M3Z_hToyjK5e1Nrk2zDYSDBlNWlEzl5Yn4ME',
    sk: 'o5ZTjimFeVvxBvBEMc8J_ciyUAi-JNV5cutJ-5gS',
    bucket: 'jnode',
    host: 'http://oyzjha0e3.bkt.clouddn.com/'
  }
}
